# ASTRA 가상기업 5개 UI 자료 v1

이 패키지는 ASTRA 데모 UI 개발팀에 전달하기 위해 기존 합성 회사 원장과 생성 문서를 묶은 자료다.

## 포함 범위

- 회사 5곳: 가상 한빛IT, 가상 해온시스템, 가상 인우블록, 가상 누리클라우드, 가상 새온에너지SW
- 기준일: 2026-04-01
- UI용 L2·L3 문서: 41개
- 모든 회사와 문서는 합성 자료다. 실제 기업, 실제 실적, 실제 인증, 실제 견적이 아니다.

## 폴더

```text
public/
  companies_catalog.json       회사 선택 화면용 공개 요약
internal/
  company_master.json          회사 사실의 정본
  company_master.schema.json   원장 스키마
  companies_ui.json            내부 UI용 회사·문서 요약
  role_access.json             역할별 접근등급 예시
  access_rule_checks.json      기존 권한 검증 자료
  manifests/                   회사별 UI 패키지 문서 목록
  documents/C01...C05/L2,L3/   회사별 문서 JSON·Markdown
PACKAGE_MANIFEST.json          패키지 파일 해시와 용도
```

## UI 적용 원칙

1. `public/companies_catalog.json`만 회사 선택 카드 등 공개 정적 화면에 사용할 수 있다.
2. `internal/` 전체를 브라우저 정적 폴더에 복사하지 않는다.
3. L2·L3 문서는 서버가 인증된 사용자 회사, tenant, 역할을 확인한 뒤 필요한 문서만 반환해야 한다.
4. 브라우저의 역할 선택 드롭다운은 권한 시연 설정일 뿐 실제 접근 통제가 아니다.
5. L2는 기업 내부 실적·인력·인증 자료, L3는 원가·견적·투찰 검토 자료다.
6. `human_approval=pending`, `review_status=unreviewed`, `rag_ingest=false` 상태를 UI에서 완료로 바꾸지 않는다.
7. `missing`, 만료 인증, 참여 보류 사유를 정상·확보 완료 상태처럼 표시하지 않는다.
8. 질문·기대답·판정표는 이 패키지에 포함하지 않았다. RAG 검색 자료에 평가 정답을 넣지 않는다.

## 권장 화면

- 회사 선택: 회사명, 지역, 규모, 전문분야, 한 줄 특징
- L2 탭: 기업·등록, 실적, 인력, 인증, 배치 계획
- L3 탭: 원가 정책, 원가 산출, 공개가격 참고, 투찰 검토
- 상태 표시: 합성 자료, 기준일, 보안등급, 사람 승인 pending, 색인 상태

## 정본과 변경

회사 공통 사실을 수정할 때는 `internal/company_master.json`의 원본인
`project-docs/가상기업/v1/company_master.json`을 먼저 수정하고 검증기를 통과시킨 뒤 이 패키지를 다시 생성한다.
UI에서 공고에 맞추려고 회사의 실적·인증·인력을 임의로 바꾸지 않는다.
