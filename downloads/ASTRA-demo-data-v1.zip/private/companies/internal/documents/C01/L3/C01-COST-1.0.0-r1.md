# 가상 한빛IT 표준 인건비·원가·마진 정책

문서 버전 1.0.0-r1 / 마스터 1.0.0. 합성 자료 기반 내부 대장.

## 원가·마진 공통 정책

가상 한빛IT · C01 · astra-c01 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| 보안등급 | L3 |
| 값의 성격 | synthetic_setting |
| 통화 | KRW |
| VAT 기준 | exclusive — VAT 제외 |
| 간접비 가정 | 12 percent_of_direct_cost · 합성 설정값 |
| 예비비 가정 | 5 percent_of_direct_cost · 합성 설정값 |
| 목표 매출대비 마진 | 15 percent_of_revenue · 합성 설정값 |
| 최저 매출대비 마진 | 8 percent_of_revenue · 합성 설정값 |
| 승인 역할 | bid_approver |
| 내부 정책 | 최저 마진 미달 시 승인 요청 또는 참여 보류. 예정가격·경쟁사 가격은 추정하지 않음. |
| 산식 | labor=sum(monthly_base * person_months * (1+employer_burden/100)); direct=labor+verified_supplier_quotes+other_direct; cost=direct*(1+overhead/100+contingency/100); proposed_net=cost/(1-target_gross_margin/100) |
| 미확보 견적 처리 | 미확보 외부 견적은 null로 유지; 0원으로 계산하거나 예산에서 역산하지 않음 |
| 반올림 정책 | 중간 계산 Decimal 유지, 최종 원 단위 반올림; 투찰 VAT는 별도 |
| 합성 증빙 레코드 ID | SYN-EV-C01-COST-POLICY |

## PM 표준 인건비

가상 한빛IT · C01 · astra-c01 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| 통화 | KRW |
| VAT 기준 | exclusive — VAT 제외 |
| 직무 | PM |
| 1인·1개월 기준급 | 3,900,000 KRW/person_month · 합성 설정값 |
| 사업주 부담 가정 | 18 percent · 합성 설정값 |

## SW개발자 표준 인건비

가상 한빛IT · C01 · astra-c01 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| 통화 | KRW |
| VAT 기준 | exclusive — VAT 제외 |
| 직무 | SW개발자 |
| 1인·1개월 기준급 | 4,130,000 KRW/person_month · 합성 설정값 |
| 사업주 부담 가정 | 18 percent · 합성 설정값 |

## QA 표준 인건비

가상 한빛IT · C01 · astra-c01 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| 통화 | KRW |
| VAT 기준 | exclusive — VAT 제외 |
| 직무 | QA |
| 1인·1개월 기준급 | 4,360,000 KRW/person_month · 합성 설정값 |
| 사업주 부담 가정 | 18 percent · 합성 설정값 |

## 운영엔지니어 표준 인건비

가상 한빛IT · C01 · astra-c01 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 수치·날짜·보유 사실은 합성 원장의 설정이며 계산값은 별도 표시한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| 통화 | KRW |
| VAT 기준 | exclusive — VAT 제외 |
| 직무 | 운영엔지니어 |
| 1인·1개월 기준급 | 4,590,000 KRW/person_month · 합성 설정값 |
| 사업주 부담 가정 | 18 percent · 합성 설정값 |
