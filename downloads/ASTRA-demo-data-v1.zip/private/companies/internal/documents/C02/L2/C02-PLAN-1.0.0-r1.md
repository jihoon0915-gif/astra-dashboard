# 가상 해온시스템 공고별 배치 계획

R26BK01474723-000 / SC-C02-REVIEW-r1 / 1.0.0-r1

합성 검토 초안. 제출 승인·증빙 확보·색인 적재 모두 미완료.

## 배치 전제

가상 해온시스템 · C02 · astra-c02 · L2 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 회사 사실은 합성 원장 기준이다. 공고 추출값은 source_ids, 합성 계획값은 origin·basis, 계산값은 formula로 구분한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| bid_key | R26BK01474723-000 |
| scenario_id | SC-C02-REVIEW-r1 |
| basis | 공고 명시 기간. 중급 기술자 잔여 0.5 FTE를 활용하는 내부 검토안이며 SLA 충족 보증이 아님. |
| actual_contract_start | null — 미설정/해당 없음; 유효·완료·0원으로 간주하지 않음 |
| start_origin | source_extracted |
| end_origin | source_extracted |
| source_ids [1] | A-BS-PERIOD |
| source_ids [2] | S-BS-STAFF |
| source_ids [3] | A-BS-SLA |
| source_ids [4] | A-BS-CONFIRM |
| source_ids [5] | A-BS-SUPPORT |
| source_ids [6] | A-BS-AGREEMENT-1 |
| source_ids [7] | A-BS-AGREEMENT-2 |
| staffing_status | 독립 합성 대안; 기존 배치와 합산 검증, 실행 미승인 |
| constraint | 문서에 나타난 자격·필수 증빙과 이행 의무를 별도 검토해야 한다. 이 초안은 전체 적격 판정이 아니다. |

## C02-P-02 배치 초안

가상 해온시스템 · C02 · astra-c02 · L2 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 회사 사실은 합성 원장 기준이다. 공고 추출값은 source_ids, 합성 계획값은 origin·basis, 계산값은 formula로 구분한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| 배치 ID | C02-R1-A1 |
| 인력 ID | C02-P-02 |
| 시작일 | 2026-05-01 |
| 종료일 | 2026-12-31 |
| 투입 FTE | 0.5 FTE · 합성 설정값 |
| planned_work | 중급 유지관리 기술자 |
| 값의 성격 | synthetic_setting |
| rationale | 기존 확정 배치의 잔여 가용량 안에서 역할별로 책정한 내부 작업량; 발주기관 필수 인원·등급 판정 아님 |
| 기존 확정 배치 [1] / 배치 ID | C02-P-02-A01 |
| 기존 확정 배치 [1] / 실적 ID | C02-PRJ-03 |
| 기존 확정 배치 [1] / 시작일 | 2026-01-01 |
| 기존 확정 배치 [1] / 종료일 | 2026-12-31 |
| 기존 확정 배치 [1] / 투입 FTE | 0.5 FTE · 합성 설정값 |
| 기존 확정 배치 [1] / 상태 | committed |
| 고용 종료일 | null — 미설정/해당 없음; 유효·완료·0원으로 간주하지 않음 |
