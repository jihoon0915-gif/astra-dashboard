# 가상 해온시스템 공고별 투찰 검토안

R26BK01474723-000 / SC-C02-REVIEW-r1 / 1.0.0-r1

합성 검토 초안. 제출 승인·증빙 확보·색인 적재 모두 미완료.

## 참여 보류 및 후속 확인

가상 해온시스템 · C02 · astra-c02 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 회사 사실은 합성 원장 기준이다. 공고 추출값은 source_ids, 합성 계획값은 origin·basis, 계산값은 formula로 구분한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| bid_key | R26BK01474723-000 |
| scenario_id | SC-C02-REVIEW-r1 |
| 상태 | hold_not_submission_ready |
| holds [1] | 기술지원 확약서 미확보(계약 전 제출 의무) |
| holds [2] | 중급 기술자 1명의 부분 투입만으로 장애 2시간 도착·4시간 복구 및 대체 인력 확보 여부 미검증 |
| holds [3] | 장비 교체·부품 비용 범위 및 공급사 최종 적용 조건 미확정 |
| bid_price | null — 미설정/해당 없음; 유효·완료·0원으로 간주하지 않음 |
| source_ids [1] | A-BS-PERIOD |
| source_ids [2] | S-BS-STAFF |
| source_ids [3] | A-BS-SLA |
| source_ids [4] | A-BS-CONFIRM |
| source_ids [5] | A-BS-SUPPORT |
| source_ids [6] | A-BS-AGREEMENT-1 |
| source_ids [7] | A-BS-AGREEMENT-2 |
| decision_scope | 전체 적격 여부 미확정. 원가 일부 산출과 공급권한·증빙 확보를 혼동하지 않는다. |
| approval_status | pending |
| alternative_group | C02-2026-OPTIONS |
