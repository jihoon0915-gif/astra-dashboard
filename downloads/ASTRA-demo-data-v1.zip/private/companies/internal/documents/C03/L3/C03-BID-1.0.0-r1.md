# 가상 인우블록 공고별 투찰 검토안

R26BK01518315-000 / SC-C03-REVIEW-r1 / 1.0.0-r1

합성 검토 초안. 제출 승인·증빙 확보·색인 적재 모두 미완료.

## 참여 보류 및 후속 확인

가상 인우블록 · C03 · astra-c03 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 회사 사실은 합성 원장 기준이다. 공고 추출값은 source_ids, 합성 계획값은 origin·basis, 계산값은 formula로 구분한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| bid_key | R26BK01518315-000 |
| scenario_id | SC-C03-REVIEW-r1 |
| 상태 | hold_not_submission_ready |
| holds [1] | 총괄책임자와 세부 개발 범위에 대한 발주처 협의 미완료 |
| holds [2] | 기술등급 및 제출용 경력·가입자 증명 확인 필요 |
| holds [3] | 기존 인프라 활용 전제이며 추가 상용SW·보안 도구 비용 미확정 |
| bid_price | null — 미설정/해당 없음; 유효·완료·0원으로 간주하지 않음 |
| source_ids [1] | A-IC-PERIOD |
| source_ids [2] | A-IC-INFRA |
| source_ids [3] | A-IC-STAFF |
| source_ids [4] | S-IC-REGION |
| decision_scope | 전체 적격 여부 미확정. 원가 일부 산출과 공급권한·증빙 확보를 혼동하지 않는다. |
| approval_status | pending |
| alternative_group | C03-2026-OPTIONS |
