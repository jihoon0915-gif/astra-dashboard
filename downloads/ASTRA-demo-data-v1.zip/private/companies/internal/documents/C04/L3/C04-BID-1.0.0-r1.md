# 가상 누리클라우드 공고별 투찰 검토안

R26BK01574547-000 / SC-C04-REVIEW-r1 / 1.0.0-r1

합성 검토 초안. 제출 승인·증빙 확보·색인 적재 모두 미완료.

## 참여 보류 및 후속 확인

가상 누리클라우드 · C04 · astra-c04 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 회사 사실은 합성 원장 기준이다. 공고 추출값은 source_ids, 합성 계획값은 origin·basis, 계산값은 formula로 구분한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| bid_key | R26BK01574547-000 |
| scenario_id | SC-C04-REVIEW-r1 |
| 상태 | hold_not_submission_ready |
| holds [1] | 공급 대상 서비스 CSAP 증빙 missing |
| holds [2] | 공급 계약·권한 missing |
| holds [3] | 서버·스토리지·트래픽·보안·솔루션을 포함하는 전체 동일 규격 공급가격 미확정 |
| bid_price | null — 미설정/해당 없음; 유효·완료·0원으로 간주하지 않음 |
| source_ids [1] | A-CL-PERIOD |
| source_ids [2] | A-CL-SPEC |
| source_ids [3] | S-CL-CSAP |
| source_ids [4] | S-CL-ISMS |
| decision_scope | 전체 적격 여부 미확정. 원가 일부 산출과 공급권한·증빙 확보를 혼동하지 않는다. |
| approval_status | pending |
| alternative_group | C04-2026-OPTIONS |
