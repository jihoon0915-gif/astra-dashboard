# 가상 새온에너지SW 공고별 투찰 검토안

R26BK01505744-000 / SC-C05-REVIEW-r1 / 1.0.0-r1

합성 검토 초안. 제출 승인·증빙 확보·색인 적재 모두 미완료.

## 참여 보류 및 후속 확인

가상 새온에너지SW · C05 · astra-c05 · L3 · 상태 기준일 2026-04-01

합성 자료 기반 내부 대장. 실제 발급 증명서가 아니다. 회사 사실은 합성 원장 기준이다. 공고 추출값은 source_ids, 합성 계획값은 origin·basis, 계산값은 formula로 구분한다.
문서 생성은 증빙 확보와 다르다. missing은 그대로 미확보 상태다.

| 항목 | 값 |
|---|---|
| bid_key | R26BK01505744-000 |
| scenario_id | SC-C05-REVIEW-r1 |
| 상태 | hold_not_submission_ready |
| holds [1] | PC·게이트웨이·서버랙·UPS·스위치·상용SW 전체 견적 미확보 |
| holds [2] | 시험설비 인터페이스와 현장 설치 조건 미확정 |
| holds [3] | 제출 일정의 요일 표기 및 계약 일정은 공식 확인 전 확정하지 않음 |
| bid_price | null — 미설정/해당 없음; 유효·완료·0원으로 간주하지 않음 |
| source_ids [1] | A-EN-PERIOD |
| source_ids [2] | A-EN-SPEC |
| source_ids [3] | A-EN-DIRECT |
| source_ids [4] | S-EN-REG |
| source_ids [5] | S-EN-EXP |
| decision_scope | 전체 적격 여부 미확정. 원가 일부 산출과 공급권한·증빙 확보를 혼동하지 않는다. |
| approval_status | pending |
| alternative_group | C05-2026-OPTIONS |
